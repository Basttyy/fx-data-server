<?php class_exists('Basttyy\FxDataServer\libs\Templater') or exit; ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title><?php echo  $title  ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style type="text/css">
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap');
  *,
  body{
    -ms-text-size-adjust: 100%; /* 1 */
    -webkit-text-size-adjust: 100%; /* 2 */
    font-family: 'Roboto', sans-serif;
		margin: 0;
		padding: 0;
		box-sizing: border-box;
		color: #777777;
  }
   
		table{
			width: 90%;
      max-width: 500px;
      margin: 0 auto;
      background: white;
			border-collapse: separate;
  		border-spacing: 0 25px;
		}
		tr.footer{
			color: #01002C;
			padding: 15px 30px;
			background: #F5F8FF;
		}
		p{
			font-size: 14px;
			line-height: 20px;
		}
		
		a{
			text-decoration: none;
			color: #367CFF;
			font-size: 16px;
		}
		a.button{
			padding: 10px 25px;
			border-radius: 8px;
			background: #367CFF;
			width: fit-content;
			text-decoration: none;
			color: white;
			font-size: 16px;
		}
  
  </style>

</head>
<body>
<table >
	<tbody>
		
<tr>
    <td>
        <img style="width: 100%;" src="https://firebasestorage.googleapis.com/v0/b/tradingio.appspot.com/o/app%20images%2Fforgot_password.png?alt=media&token=b6466543-aed3-4535-919a-342f1ced91f3" />
    </td>
</tr>


		
<tr>
    <td style="padding: 0px 30px">
        <h2 style="color: black; font-weight: 700; margin-bottom: 20px;"><?php echo  $header  ?></h2>
        <?php foreach($contents as $content): ?>
            <p style="margin-bottom: 10px;"><?php echo  $content  ?></p>
        <?php endforeach; ?>
    </td>
</tr>


		
    <?php foreach($links as $label => $link): ?>
        <tr>
            <td style="padding: 0px 30px">
                <a class="button" href="<?php echo  $link  ?>"><?php echo  $label  ?></a>
            </td>
        </tr>
    <?php endforeach; ?>

    <tr>
        <td style="padding: 0px 30px">
            <p>Thanks <br>Tradingio Team.</p>
        </td>
    </tr>


		
<tr class="footer" >
    <td style="padding: 15px 30px;">
        <p style="color: #01002C;">This email was sent by <?php echo  $sender_email  ?></p>
        <p style="margin-top: 20px; color: #01002C;">
            Lagos, Nigeria. <br> © 2023 Tradingio
        </p>
    </td>
</tr>

			
	</tbody>
</table>

</body>
</html>









